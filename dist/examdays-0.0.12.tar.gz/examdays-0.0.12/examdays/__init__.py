__all__ = ["examdays"]
from .function import exam