# Examdays

*A Python module that helps you to calculate how many days will you have for preparing your exam.*

Module used:
[Pendulum](https://pypi.org/project/pendulum/)

### Usage:

```python
from examdays import exam

exam(end_year, end_month, end_day)

# For example
# exam(2021, 6, 28)

```
